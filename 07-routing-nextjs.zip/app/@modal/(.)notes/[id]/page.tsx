import NotePreview from './NotePreview.client';

export default function NotePreviewPage() {
  return <NotePreview />;
}
