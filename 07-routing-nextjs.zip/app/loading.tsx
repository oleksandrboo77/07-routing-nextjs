export default function Loading() {
  return <p>Loading, please wait...</p>;
}
